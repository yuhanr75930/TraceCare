﻿namespace MyTraceCare.Views
{
    public class ClinicianAlerts
    {
    }
}
