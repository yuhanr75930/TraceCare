﻿namespace MyTraceCare.Models.ViewModels
{
    public class AdminDashboardViewModel
    {
        public int TotalPatients { get; set; }
        public int TotalClinicians { get; set; }
        public int TotalAdmins { get; set; }
        public int TotalAlerts { get; set; }
    }
}
