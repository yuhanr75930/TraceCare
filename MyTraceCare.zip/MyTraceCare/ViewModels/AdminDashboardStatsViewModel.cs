﻿namespace MyTraceCare.ViewModels
{
    public class AdminDashboardStatsViewModel
    {
        public int TotalUsers { get; set; }
        public int TotalPatients { get; set; }
        public int TotalClinicians { get; set; }
        public int TotalAdmins { get; set; }
        public int TotalAlerts { get; set; }
    }
}
